import { useState, useRef } from 'react';
import {
  ChefHat, Calendar, ShoppingCart, Settings, Upload, Download,
  Plus, Trash2, Save, X, Palette, Users, Globe,
  Image as ImageIcon, Edit2, ChevronDown, ChevronUp,
  Search, Check,
  UtensilsCrossed,
  Package, Clock
} from 'lucide-react';

// ============ TYPES ============
interface Recipe {
  id: string;
  name: string;
  category: string;
  image: string;
  ingredients: string[];
  instructions: string;
  prepTime: number;
  cookTime: number;
  servings: number;
  price: number;
  notes: string;
  imageBrightness: number;
  imageContrast: number;
}

interface Product {
  id: string;
  item: string;
  artNr: string;
  category: string;
  price: number;
  unit: string;
  status: string;
  notes: string;
}

interface ShoppingItem {
  product: Product;
  quantity: number;
}

interface UserProfile {
  id: string;
  name: string;
  avatar: string;
  bio: string;
}

interface CustomTheme {
  id: string;
  name: string;
  primary: string;
  secondary: string;
  bgFrom: string;
  bgVia: string;
  bgTo: string;
  cardBg: string;
  textPrimary: string;
  textSecondary: string;
}

interface MenuPlan {
  [dateKey: string]: Recipe | null;
}

// ============ DEFAULT DATA ============
const DEFAULT_PRODUCTS: Product[] = [
  { id: 'p1', item: 'Kycklingfile', artNr: 'KFC001', category: 'Kött & Fågel', price: 89.90, unit: 'kg', status: 'active', notes: 'Färsk' },
  { id: 'p2', item: 'Laxfile', artNr: 'LSH002', category: 'Fisk & Skaldjur', price: 129.90, unit: 'kg', status: 'active', notes: 'Norsk lax' },
  { id: 'p3', item: 'Spaghetti', artNr: 'PST003', category: 'Pasta & Ris', price: 12.90, unit: 'pk', status: 'active', notes: '500g' },
  { id: 'p4', item: 'Tomatsås', artNr: 'TMS004', category: 'Såser', price: 24.90, unit: 'burk', status: 'active', notes: '' },
  { id: 'p5', item: 'Ost', artNr: 'OST005', category: 'Mejeri', price: 89.90, unit: 'kg', status: 'active', notes: 'Västerbotten' },
  { id: 'p6', item: 'Mjölk', artNr: 'MLK006', category: 'Mejeri', price: 18.90, unit: 'l', status: 'active', notes: '1.5% fetthalt' },
  { id: 'p7', item: 'Smör', artNr: 'SBR007', category: 'Mejeri', price: 45.90, unit: 'pk', status: 'active', notes: '250g' },
  { id: 'p8', item: 'Brod', artNr: 'BRD008', category: 'Bakverk', price: 29.90, unit: 'st', status: 'active', notes: 'Grovt brod' },
  { id: 'p9', item: 'Agurk', artNr: 'AGR009', category: 'Grönsaker', price: 15.90, unit: 'st', status: 'active', notes: '' },
  { id: 'p10', item: 'Tomat', artNr: 'TMT010', category: 'Grönsaker', price: 34.90, unit: 'kg', status: 'active', notes: '' },
  { id: 'p11', item: 'Lök', artNr: 'LK011', category: 'Grönsaker', price: 12.90, unit: 'nät', status: 'active', notes: '' },
  { id: 'p12', item: 'Morötter', artNr: 'MRT012', category: 'Grönsaker', price: 19.90, unit: 'pk', status: 'active', notes: '1kg' },
  { id: 'p13', item: 'Potatis', artNr: 'PTS013', category: 'Grönsaker', price: 9.90, unit: 'kg', status: 'active', notes: '' },
  { id: 'p14', item: 'Ris', artNr: 'RIS014', category: 'Pasta & Ris', price: 22.90, unit: 'kg', status: 'active', notes: 'Basmati' },
  { id: 'p15', item: 'Olivolja', artNr: 'OLJ015', category: 'Oljor & Vinäger', price: 69.90, unit: 'fl', status: 'active', notes: '500ml' },
  { id: 'p16', item: 'Vinäger', artNr: 'VNG016', category: 'Oljor & Vinäger', price: 34.90, unit: 'fl', status: 'active', notes: 'Balsamico' },
  { id: 'p17', item: 'Kaffe', artNr: 'KFE017', category: 'Drycker', price: 89.90, unit: 'pk', status: 'active', notes: '500g' },
  { id: 'p18', item: 'Te', artNr: 'TEE018', category: 'Drycker', price: 49.90, unit: 'pk', status: 'active', notes: '20 påsar' },
  { id: 'p19', item: 'Apelsinjuice', artNr: 'APL019', category: 'Drycker', price: 24.90, unit: 'l', status: 'active', notes: '' },
  { id: 'p20', item: 'Minivatten', artNr: 'VTS020', category: 'Drycker', price: 14.90, unit: 'fl', status: 'active', notes: '1.5l' },
];

const DEFAULT_RECIPES: Recipe[] = [
  {
    id: 'r1',
    name: 'Spaghetti Carbonara',
    category: 'Pasta',
    image: '',
    ingredients: ['Spaghetti 400g', 'Bacon 200g', 'Ägg 4 st', 'Ost 100g', 'Svartpeppar'],
    instructions: '1. Koka spaghettin i saltat vatten.\n2. Stek baconet tills det är krispigt.\n3. Vispa ägg och riven ost.\n4. Blanda pasta med baconet.\n5. Tillsätt ägblandningen av värmen.\n6. Servera med svartpeppar.',
    prepTime: 15,
    cookTime: 15,
    servings: 4,
    price: 85,
    notes: 'Klassisk italiensk rätt',
    imageBrightness: 100,
    imageContrast: 100,
  },
  {
    id: 'r2',
    name: 'Grillad Lax med Citron',
    category: 'Fisk',
    image: '',
    ingredients: ['Laxfile 500g', 'Citron 1 st', 'Dill', 'Olivolja', 'Salt & Peppar'],
    instructions: '1. Värm ugnen till 200°C.\n2. Pensla laxen med olivolja.\n3. Pressa citron över fisken.\n4. Strö över dill, salt och peppar.\n5. Grilla i 12-15 minuter.\n6. Servera med grönsaker.',
    prepTime: 10,
    cookTime: 15,
    servings: 2,
    price: 145,
    notes: 'Enkel och nyttig middag',
    imageBrightness: 100,
    imageContrast: 100,
  },
  {
    id: 'r3',
    name: 'Kyckling Curry',
    category: 'Kyckling',
    image: '',
    ingredients: ['Kycklingfile 500g', 'Currypaste 2 msk', 'Kokosmjölk 4dl', 'Ris 200g', 'Grönsaker'],
    instructions: '1. Skär kycklingen i bitar.\n2. Stek kycklingen i gryta.\n3. Tillsätt currypaste och låt fräsa.\n4. Häll i kokosmjölk.\n5. Addera grönsaker och koka 15 min.\n6. Servera med ris.',
    prepTime: 15,
    cookTime: 20,
    servings: 4,
    price: 120,
    notes: 'Mild och barnvänlig',
    imageBrightness: 100,
    imageContrast: 100,
  },
  {
    id: 'r4',
    name: 'Caesarsallad',
    category: 'Sallad',
    image: '',
    ingredients: ['Sallad 1 st', 'Kyckling 200g', 'Croutons', 'Parmesan', 'Caesarsås'],
    instructions: '1. Grilla eller stek kycklingen.\n2. Skör salladen.\n3. Blanda med caesarsås.\n4. Toppa med kyckling, croutons och parmesan.\n5. Servera direkt.',
    prepTime: 10,
    cookTime: 10,
    servings: 2,
    price: 95,
    notes: 'Perfekt lunch',
    imageBrightness: 100,
    imageContrast: 100,
  },
  {
    id: 'r5',
    name: 'Köttbullar med Potatismos',
    category: 'Kött',
    image: '',
    ingredients: ['Köttfärs 500g', 'Brödsmulor', 'Lök', 'Ägg', 'Gräddsås', 'Potatis'],
    instructions: '1. Blanda köttfärs, lök, ägg och brödsmulor.\n2. Rulla till bollar.\n3. Stek i smör tills genomstekta.\n4. Gör gräddsås i stekpannan.\n5. Koka potatis och gör mos.\n6. Servera med lingonsylt.',
    prepTime: 20,
    cookTime: 25,
    servings: 4,
    price: 115,
    notes: 'Svenska klassikern',
    imageBrightness: 100,
    imageContrast: 100,
  },
  {
    id: 'r6',
    name: 'Vegetarisk Lasagne',
    category: 'Vegetariskt',
    image: '',
    ingredients: ['Lasagneplattor', 'Tomatsås', 'Spenat', 'Ost', 'Bechamelsås'],
    instructions: '1. Förvärp spenaten.\n2. Blanda med tomatsås.\n3. Bygg lasagne i ugnform.\n4. Lager med plattor och sås.\n5. Top med ost.\n6. Grädda 200°C i 40 min.',
    prepTime: 20,
    cookTime: 40,
    servings: 6,
    price: 130,
    notes: 'Fyllig och mättande',
    imageBrightness: 100,
    imageContrast: 100,
  },
];

const THEMES: CustomTheme[] = [
  {
    id: 'light',
    name: 'Ljust',
    primary: '#6366f1',
    secondary: '#8b5cf6',
    bgFrom: '#f8fafc',
    bgVia: '#f1f5f9',
    bgTo: '#e2e8f0',
    cardBg: '#ffffff',
    textPrimary: '#1e293b',
    textSecondary: '#64748b',
  },
  {
    id: 'dark',
    name: 'Mörkt',
    primary: '#818cf8',
    secondary: '#a78bfa',
    bgFrom: '#0f172a',
    bgVia: '#1e293b',
    bgTo: '#334155',
    cardBg: '#1e293b',
    textPrimary: '#f1f5f9',
    textSecondary: '#94a3b8',
  },
  {
    id: 'ocean',
    name: 'Hav',
    primary: '#06b6d4',
    secondary: '#0891b2',
    bgFrom: '#ecfeff',
    bgVia: '#cffafe',
    bgTo: '#a5f3fc',
    cardBg: '#ecfeff',
    textPrimary: '#164e63',
    textSecondary: '#155e75',
  },
  {
    id: 'forest',
    name: 'Skog',
    primary: '#22c55e',
    secondary: '#16a34a',
    bgFrom: '#f0fdf4',
    bgVia: '#dcfce7',
    bgTo: '#bbf7d0',
    cardBg: '#f0fdf4',
    textPrimary: '#14532d',
    textSecondary: '#166534',
  },
  {
    id: 'sunset',
    name: 'Solnedgång',
    primary: '#f97316',
    secondary: '#ea580c',
    bgFrom: '#fff7ed',
    bgVia: '#ffedd5',
    bgTo: '#fed7aa',
    cardBg: '#fff7ed',
    textPrimary: '#7c2d12',
    textSecondary: '#9a3412',
  },
  {
    id: 'berry',
    name: 'Bär',
    primary: '#ec4899',
    secondary: '#db2777',
    bgFrom: '#fdf2f8',
    bgVia: '#fce7f3',
    bgTo: '#fbcfe8',
    cardBg: '#fdf2f8',
    textPrimary: '#831843',
    textSecondary: '#9d174d',
  },
];

const TRANSLATIONS: Record<string, Record<string, string>> = {
  en: {
    recipes: 'Recipes',
    menu: 'Menu Plan',
    purchases: 'Products',
    shopping: 'Shopping List',
    settings: 'Settings',
    search: 'Search recipes, products...',
    addRecipe: 'Add Recipe',
    noRecipes: 'No recipes found',
    servings: 'servings',
    price: 'Price',
    category: 'Category',
    ingredients: 'Ingredients',
    instructions: 'Instructions',
    prepTime: 'Prep Time',
    cookTime: 'Cook Time',
    notes: 'Notes',
    save: 'Save',
    cancel: 'Cancel',
    editRecipe: 'Edit Recipe',
    deleteRecipe: 'Delete Recipe',
    uploadImage: 'Upload Image',
    removeImage: 'Remove Image',
    addToShopping: 'Add to Shopping',
    weekMenu: 'Weekly Menu',
    prevWeek: 'Previous Week',
    nextWeek: 'Next Week',
    totalCost: 'Total Cost',
    selectRecipe: 'Select Recipe',
    clearDay: 'Clear Day',
    shoppingList: 'Shopping List',
    checkout: 'Checkout',
    clearList: 'Clear List',
    importCSV: 'Import CSV',
    exportCSV: 'Export CSV',
    products: 'Products',
    addProduct: 'Add Product',
    item: 'Item',
    artNr: 'Art. No.',
    unit: 'Unit',
    status: 'Status',
    manageThemes: 'Manage Themes',
    createTheme: 'Create Theme',
    themeName: 'Theme Name',
    primaryColor: 'Primary Color',
    bgColor: 'Background Color',
    manageUsers: 'Manage Users',
    addUser: 'Add User',
    userName: 'User Name',
    bio: 'Bio',
    language: 'Language',
    currency: 'Currency',
    weekends: 'Include Weekends',
    emptyShopping: 'Shopping list is empty',
    total: 'Total',
  },
  sv: {
    recipes: 'Recept',
    menu: 'Menyplanering',
    purchases: 'Produkter',
    shopping: 'Inköpslista',
    settings: 'Inställningar',
    search: 'Sök recept, produkter...',
    addRecipe: 'Lägg till Recept',
    noRecipes: 'Inga recept hittade',
    servings: 'portioner',
    price: 'Pris',
    category: 'Kategori',
    ingredients: 'Ingredienser',
    instructions: 'Instruktioner',
    prepTime: 'Förberedelsetid',
    cookTime: 'Tillagningstid',
    notes: 'Anteckningar',
    save: 'Spara',
    cancel: 'Avbryt',
    editRecipe: 'Redigera Recept',
    deleteRecipe: 'Ta bort Recept',
    uploadImage: 'Ladda upp bild',
    removeImage: 'Ta bort bild',
    addToShopping: 'Lägg till inköp',
    weekMenu: 'Veckomeny',
    prevWeek: 'Föregående vecka',
    nextWeek: 'Nästa vecka',
    totalCost: 'Total kostnad',
    selectRecipe: 'Välj recept',
    clearDay: 'Rensa dag',
    shoppingList: 'Inköpslista',
    checkout: 'Kassa',
    clearList: 'Rensa lista',
    importCSV: 'Importera CSV',
    exportCSV: 'Exportera CSV',
    products: 'Produkter',
    addProduct: 'Lägg till produkt',
    item: 'Vara',
    artNr: 'Art.nr',
    unit: 'Enhet',
    status: 'Status',
    manageThemes: 'Hantera teman',
    createTheme: 'Skapa tema',
    themeName: 'Temanamn',
    primaryColor: 'Primär färg',
    bgColor: 'Bakgrundsfärg',
    manageUsers: 'Hantera användare',
    addUser: 'Lägg till användare',
    userName: 'Användarnamn',
    bio: 'Bio',
    language: 'Språk',
    currency: 'Valuta',
    weekends: 'Inkludera helger',
    emptyShopping: 'Inköpslistan är tom',
    total: 'Totalt',
  },
};

const DAYS_EN = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const DAYS_SV = ['Måndag', 'Tisdag', 'Onsdag', 'Torsdag', 'Fredag', 'Lördag', 'Söndag'];

// ============ HELPERS ============
const formatPrice = (price: number, currency: string): string => {
  const symbols: Record<string, string> = { SEK: ' kr', EUR: '€', USD: '$', GBP: '£' };
  const symbol = symbols[currency] || ' kr';
  return currency === 'SEK' 
    ? `${price.toFixed(2)}${symbol}` 
    : `${symbol}${price.toFixed(2)}`;
};

const genId = () => Math.random().toString(36).slice(2, 11);

const getWeekDates = (weekOffset: number = 0) => {
  const now = new Date();
  const currentDay = now.getDay();
  const monday = new Date(now);
  monday.setDate(now.getDate() - (currentDay === 0 ? 6 : currentDay - 1) + (weekOffset * 7));
  
  const dates = [];
  for (let i = 0; i < 7; i++) {
    const date = new Date(monday);
    date.setDate(monday.getDate() + i);
    dates.push(date);
  }
  return dates;
};

// ============ MAIN APP ============
export default function App() {
  const [showApp, setShowApp] = useState(true);

  if (!showApp) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-50 via-white to-zinc-100 p-8">
        <div className="space-y-6 text-center">
          <div className="inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-500 to-indigo-600 shadow-lg shadow-indigo-200">
            <ChefHat className="h-8 w-8 text-white" />
          </div>
          <div className="space-y-2">
            <h1 className="text-3xl font-semibold tracking-tight text-slate-900">Food Planner</h1>
            <p className="text-slate-500">Plan your meals, manage recipes, and shop smart</p>
          </div>
          <button
            onClick={() => setShowApp(true)}
            className="px-6 py-3 bg-gradient-to-br from-violet-500 to-indigo-600 text-white rounded-xl font-medium hover:scale-105 transition-all"
          >
            Get Started
          </button>
        </div>
      </div>
    );
  }

  return <FoodPlannerApp />;
}

function FoodPlannerApp() {
  // State
  const [activePage, setActivePage] = useState<'recipes' | 'menu' | 'purchases' | 'shopping' | 'settings'>('recipes');
  const [currency, setCurrency] = useState<'SEK' | 'EUR' | 'USD' | 'GBP'>('SEK');
  const [themeId, setThemeId] = useState('light');
  const [customThemes, setCustomThemes] = useState<CustomTheme[]>([]);
  const [language, setLanguage] = useState<'en' | 'sv'>('sv');
  const [includeWeekends, setIncludeWeekends] = useState(false);

  const [recipes, setRecipes] = useState<Recipe[]>(DEFAULT_RECIPES);
  const [products, setProducts] = useState<Product[]>(DEFAULT_PRODUCTS);
  const [shoppingList, setShoppingList] = useState<ShoppingItem[]>([]);
  const [menuPlan, setMenuPlan] = useState<MenuPlan>({});
  const [users, setUsers] = useState<UserProfile[]>([
    { id: 'u1', name: 'Anna', avatar: '', bio: 'Matälskare' },
    { id: 'u2', name: 'Erik', avatar: '', bio: 'Lagar mat hemma' },
  ]);
  const [currentUserId, setCurrentUserId] = useState('u1');

  // UI State
  const [showRecipeModal, setShowRecipeModal] = useState(false);
  const [editingRecipe, setEditingRecipe] = useState<Recipe | null>(null);
  const [showDayDetail, setShowDayDetail] = useState<string | null>(null);
  const [showUserModal, setShowUserModal] = useState(false);
  const [showThemeModal, setShowThemeModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  const [weekOffset, setWeekOffset] = useState(0);
  const [newIngredient, setNewIngredient] = useState('');
  const [editingUser, setEditingUser] = useState<UserProfile | null>(null);
  const [newThemeName, setNewThemeName] = useState('');
  const [newThemePrimary, setNewThemePrimary] = useState('#6366f1');
  const [newThemeBg, setNewThemeBg] = useState('#f8fafc');

  // Product Modal
  const [showProductModal, setShowProductModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  const recipeImageRef = useRef<HTMLInputElement>(null);
  const csvInputRef = useRef<HTMLInputElement>(null);

  const t = TRANSLATIONS[language];
  const days = language === 'sv' ? DAYS_SV : DAYS_EN;
  const currentTheme = [...THEMES, ...customThemes].find(th => th.id === themeId) || THEMES[0];
  const weekDates = getWeekDates(weekOffset);

  const allCategories = Array.from(new Set(products.map(p => p.category))).sort();

  // Filtered data
  const filteredRecipes = recipes.filter(r =>
    !searchTerm || 
    r.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    r.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredProducts = products.filter(p => {
    const matchSearch = !searchTerm || 
      p.item.toLowerCase().includes(searchTerm.toLowerCase()) || 
      p.artNr.toLowerCase().includes(searchTerm.toLowerCase());
    const matchCat = !filterCategory || p.category === filterCategory;
    return matchSearch && matchCat;
  });

  const weekDays = includeWeekends ? days : days.slice(0, 5);
  const weekDatesFiltered = includeWeekends ? weekDates : weekDates.slice(0, 5);

  const weekTotalCost = Object.values(menuPlan).reduce((sum, r) => sum + (r?.price || 0), 0);

  // Recipe Handlers
  const openNewRecipe = () => {
    setEditingRecipe({
      id: '',
      name: '',
      category: '',
      image: '',
      ingredients: [''],
      instructions: '',
      prepTime: 0,
      cookTime: 0,
      servings: 2,
      price: 0,
      notes: '',
      imageBrightness: 100,
      imageContrast: 100,
    });
    setShowRecipeModal(true);
  };

  const openEditRecipe = (recipe: Recipe) => {
    setEditingRecipe({ ...recipe, ingredients: [...recipe.ingredients] });
    setShowRecipeModal(true);
  };

  const saveRecipe = () => {
    if (!editingRecipe) return;

    if (editingRecipe.id) {
      setRecipes(prev => prev.map(r => r.id === editingRecipe.id ? editingRecipe : r));
    } else {
      const newRecipe: Recipe = {
        ...editingRecipe,
        id: genId(),
      };
      setRecipes(prev => [...prev, newRecipe]);
    }
    setShowRecipeModal(false);
    setEditingRecipe(null);
  };

  const deleteRecipe = (id: string) => {
    setRecipes(prev => prev.filter(r => r.id !== id));
    // Remove from menu plan if present
    setMenuPlan(prev => {
      const updated = { ...prev };
      Object.keys(updated).forEach(key => {
        if (updated[key]?.id === id) {
          updated[key] = null;
        }
      });
      return updated;
    });
  };

  const handleRecipeImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !editingRecipe) return;

    const reader = new FileReader();
    reader.onload = (ev) => {
      setEditingRecipe(prev => prev ? { ...prev, image: ev.target?.result as string } : null);
    };
    reader.readAsDataURL(file);
  };

  const addIngredient = () => {
    if (!editingRecipe || !newIngredient.trim()) return;
    setEditingRecipe(prev => prev ? { ...prev, ingredients: [...prev.ingredients, newIngredient.trim()] } : null);
    setNewIngredient('');
  };

  const removeIngredient = (index: number) => {
    if (!editingRecipe) return;
    setEditingRecipe(prev => prev ? { ...prev, ingredients: prev.ingredients.filter((_, i) => i !== index) } : null);
  };

  const updateIngredient = (index: number, value: string) => {
    if (!editingRecipe) return;
    setEditingRecipe(prev => prev ? { ...prev, ingredients: prev.ingredients.map((ing, i) => i === index ? value : ing) } : null);
  };

  // CSV Handlers
  const handleCSVUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (ev) => {
      const text = ev.target?.result as string;
      const lines = text.split('\n').filter(line => line.trim());
      const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
      
      const newProducts: Product[] = [];
      for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',').map(v => v.trim());
        const product: Product = {
          id: genId(),
          item: values[headers.indexOf('item')] || values[0] || '',
          artNr: values[headers.indexOf('artnr')] || values[1] || '',
          category: values[headers.indexOf('category')] || values[2] || '',
          price: parseFloat(values[headers.indexOf('price')] || values[3] || '0') || 0,
          unit: values[headers.indexOf('unit')] || values[4] || 'st',
          status: 'active',
          notes: values[headers.indexOf('notes')] || values[5] || '',
        };
        if (product.item) {
          newProducts.push(product);
        }
      }
      setProducts(prev => [...prev, ...newProducts]);
    };
    reader.readAsText(file);
  };

  const downloadCSV = () => {
    const headers = 'item,artNr,category,price,unit,notes\n';
    const rows = products.map(p => 
      `${p.item},${p.artNr},${p.category},${p.price},${p.unit},${p.notes}`
    ).join('\n');
    const csv = headers + rows;
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'products.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  // Shopping handlers
  const addToShoppingList = (product: Product) => {
    setShoppingList(prev => {
      const existing = prev.find(s => s.product.id === product.id);
      if (existing) {
        return prev.map(s => s.product.id === product.id ? { ...s, quantity: s.quantity + 1 } : s);
      }
      return [...prev, { product, quantity: 1 }];
    });
  };

  const updateShoppingQuantity = (productId: string, delta: number) => {
    setShoppingList(prev => prev.map(s => {
      if (s.product.id === productId) {
        const newQty = Math.max(0, s.quantity + delta);
        return { ...s, quantity: newQty };
      }
      return s;
    }).filter(s => s.quantity > 0));
  };

  const removeFromShoppingList = (productId: string) => {
    setShoppingList(prev => prev.filter(s => s.product.id !== productId));
  };

  const clearShoppingList = () => {
    setShoppingList([]);
  };

  const shoppingTotal = shoppingList.reduce((sum, s) => sum + s.product.price * s.quantity, 0);

  // Menu handlers
  const setDayRecipe = (dateKey: string, recipe: Recipe | null) => {
    setMenuPlan(prev => ({ ...prev, [dateKey]: recipe }));
    setShowDayDetail(null);
  };

  const clearDayRecipe = (dateKey: string) => {
    setMenuPlan(prev => ({ ...prev, [dateKey]: null }));
  };

  // Product handlers
  const openNewProduct = () => {
    setEditingProduct({
      id: '',
      item: '',
      artNr: '',
      category: '',
      price: 0,
      unit: 'st',
      status: 'active',
      notes: '',
    });
    setShowProductModal(true);
  };

  const saveProduct = () => {
    if (!editingProduct) return;

    if (editingProduct.id) {
      setProducts(prev => prev.map(p => p.id === editingProduct.id ? editingProduct : p));
    } else {
      const newProduct: Product = { ...editingProduct, id: genId() };
      setProducts(prev => [...prev, newProduct]);
    }
    setShowProductModal(false);
    setEditingProduct(null);
  };

  // User handlers
  const openNewUser = () => {
    setEditingUser({
      id: '',
      name: '',
      avatar: '',
      bio: '',
    });
    setShowUserModal(true);
  };

  const saveUser = () => {
    if (!editingUser) return;

    if (editingUser.id) {
      setUsers(prev => prev.map(u => u.id === editingUser.id ? editingUser : u));
    } else {
      const newUser: UserProfile = { ...editingUser, id: genId() };
      setUsers(prev => [...prev, newUser]);
    }
    setShowUserModal(false);
    setEditingUser(null);
  };

  const deleteUser = (id: string) => {
    if (users.length <= 1) return;
    setUsers(prev => prev.filter(u => u.id !== id));
    if (currentUserId === id) {
      setCurrentUserId(prev => prev === id ? users[0]?.id || '' : prev);
    }
  };

  // Theme handler
  const addCustomTheme = () => {
    const newTheme: CustomTheme = {
      id: `custom_${genId()}`,
      name: newThemeName,
      primary: newThemePrimary,
      secondary: newThemePrimary,
      bgFrom: newThemeBg,
      bgVia: newThemeBg,
      bgTo: newThemePrimary + '22',
      cardBg: newThemeBg,
      textPrimary: '#1e293b',
      textSecondary: '#64748b',
    };
    setCustomThemes(prev => [...prev, newTheme]);
    setThemeId(newTheme.id);
    setShowThemeModal(false);
    setNewThemeName('');
    setNewThemePrimary('#6366f1');
    setNewThemeBg('#f8fafc');
  };

  const deleteCustomTheme = (id: string) => {
    setCustomThemes(prev => prev.filter(th => th.id !== id));
    if (themeId === id) {
      setThemeId('light');
    }
  };

  // Styles
  const cardStyle = {
    backgroundColor: currentTheme.cardBg,
    color: currentTheme.textPrimary,
    border: `1px solid ${currentTheme.primary}33`,
  };

  const inputStyle = {
    backgroundColor: `${currentTheme.textPrimary}10`,
    color: currentTheme.textPrimary,
    border: `1px solid ${currentTheme.textSecondary}40`,
  };

  const primaryBtnStyle = {
    background: `linear-gradient(135deg, ${currentTheme.primary}, ${currentTheme.secondary})`,
    color: '#ffffff',
  };

  const secondaryBtnStyle = {
    backgroundColor: `${currentTheme.primary}20`,
    color: currentTheme.textPrimary,
    border: `1px solid ${currentTheme.primary}40`,
  };

  return (
    <div style={{ background: `linear-gradient(135deg, ${currentTheme.bgFrom}, ${currentTheme.bgVia}, ${currentTheme.bgTo})` }} 
         className="min-h-screen transition-all duration-500 font-sans">
      
      {/* File inputs */}
      <input ref={csvInputRef} type="file" accept=".csv" className="hidden" onChange={handleCSVUpload} />
      <input ref={recipeImageRef} type="file" accept="image/*" className="hidden" onChange={handleRecipeImageUpload} />

      {/* Top Bar */}
      <header className="sticky top-0 z-40 backdrop-blur-lg" style={{ backgroundColor: `${currentTheme.cardBg}cc` }}>
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <ChefHat className="w-8 h-8" style={{ color: currentTheme.primary }} />
                <h1 className="text-xl font-bold" style={{ color: currentTheme.textPrimary }}>
                  Food Planner
                </h1>
              </div>
              
              {/* User selector */}
              <div className="flex items-center gap-2 ml-6">
                <Users className="w-5 h-5" style={{ color: currentTheme.textSecondary }} />
                <select
                  value={currentUserId}
                  onChange={e => setCurrentUserId(e.target.value)}
                  style={inputStyle}
                  className="px-3 py-1.5 rounded-lg text-sm focus:outline-none cursor-pointer"
                >
                  {users.map(u => (
                    <option key={u.id} value={u.id}>{u.name}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {/* Currency */}
              <select
                value={currency}
                onChange={e => setCurrency(e.target.value as any)}
                style={inputStyle}
                className="px-3 py-1.5 rounded-lg text-sm focus:outline-none cursor-pointer"
              >
                <option value="SEK">SEK</option>
                <option value="EUR">EUR</option>
                <option value="USD">USD</option>
                <option value="GBP">GBP</option>
              </select>

              {/* Language */}
              <button
                onClick={() => setLanguage(l => l === 'sv' ? 'en' : 'sv')}
                style={secondaryBtnStyle}
                className="px-3 py-1.5 rounded-lg text-sm flex items-center gap-2 hover:scale-105 transition-all"
              >
                <Globe className="w-4 h-4" />
                {language === 'sv' ? 'SV' : 'EN'}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="max-w-7xl mx-auto px-4 mt-4">
        <div className="flex gap-2 overflow-x-auto pb-2" style={{ backgroundColor: `${currentTheme.cardBg}40`, borderRadius: '12px', padding: '6px' }}>
          <button
            onClick={() => setActivePage('recipes')}
            style={activePage === 'recipes' ? primaryBtnStyle : { color: currentTheme.textSecondary }}
            className={`px-4 py-2 rounded-lg font-medium text-sm flex items-center gap-2 transition-all hover:scale-105 whitespace-nowrap`}
          >
            <ChefHat className="w-4 h-4" />
            {t.recipes}
          </button>
          <button
            onClick={() => setActivePage('menu')}
            style={activePage === 'menu' ? primaryBtnStyle : { color: currentTheme.textSecondary }}
            className={`px-4 py-2 rounded-lg font-medium text-sm flex items-center gap-2 transition-all hover:scale-105 whitespace-nowrap`}
          >
            <Calendar className="w-4 h-4" />
            {t.menu}
          </button>
          <button
            onClick={() => setActivePage('purchases')}
            style={activePage === 'purchases' ? primaryBtnStyle : { color: currentTheme.textSecondary }}
            className={`px-4 py-2 rounded-lg font-medium text-sm flex items-center gap-2 transition-all hover:scale-105 whitespace-nowrap`}
          >
            <Package className="w-4 h-4" />
            {t.purchases}
          </button>
          <button
            onClick={() => setActivePage('shopping')}
            style={activePage === 'shopping' ? primaryBtnStyle : { color: currentTheme.textSecondary }}
            className={`px-4 py-2 rounded-lg font-medium text-sm flex items-center gap-2 transition-all hover:scale-105 whitespace-nowrap`}
          >
            <ShoppingCart className="w-4 h-4" />
            {t.shopping} ({shoppingList.length})
          </button>
          <button
            onClick={() => setActivePage('settings')}
            style={activePage === 'settings' ? primaryBtnStyle : { color: currentTheme.textSecondary }}
            className={`px-4 py-2 rounded-lg font-medium text-sm flex items-center gap-2 transition-all hover:scale-105 whitespace-nowrap`}
          >
            <Settings className="w-4 h-4" />
            {t.settings}
          </button>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Search bar */}
        <div className="relative mb-6">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5" style={{ color: currentTheme.textSecondary }} />
          <input
            type="text"
            placeholder={t.search}
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            style={inputStyle}
            className="w-full pl-12 pr-4 py-3 rounded-2xl text-sm focus:outline-none focus:ring-2"
          />
        </div>

        {/* Recipes Page */}
        {activePage === 'recipes' && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold" style={{ color: currentTheme.textPrimary }}>{t.recipes}</h2>
              <button onClick={openNewRecipe} style={primaryBtnStyle} className="px-5 py-2.5 rounded-xl font-medium flex items-center gap-2 hover:scale-105 transition-all shadow-lg">
                <Plus className="w-5 h-5" /> {t.addRecipe}
              </button>
            </div>

            {filteredRecipes.length === 0 ? (
              <div style={cardStyle} className="rounded-2xl p-12 text-center shadow-lg">
                <ChefHat className="w-16 h-16 mx-auto mb-4 opacity-70" style={{ color: currentTheme.primary }} />
                <p style={{ color: currentTheme.textSecondary }}>{t.noRecipes}</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredRecipes.map(recipe => (
                  <div key={recipe.id} style={cardStyle} className="rounded-2xl overflow-hidden hover:shadow-xl transition-all group shadow-lg">
                    <div className="relative h-48 overflow-hidden">
                      {recipe.image ? (
                        <img
                          src={recipe.image}
                          alt={recipe.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          style={{ filter: `brightness(${recipe.imageBrightness}%) contrast(${recipe.imageContrast}%)` }}
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center" style={{ background: `linear-gradient(135deg, ${currentTheme.primary}15, ${currentTheme.secondary}15)` }}>
                          <ChefHat className="w-20 h-20 opacity-40" style={{ color: currentTheme.primary }} />
                        </div>
                      )}
                      <div className="absolute top-3 right-3 flex gap-2">
                        <button onClick={() => openEditRecipe(recipe)} className="p-2 bg-black/60 hover:bg-black/80 rounded-lg text-white transition-all backdrop-blur-sm">
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button onClick={() => deleteRecipe(recipe.id)} className="p-2 bg-red-500/80 hover:bg-red-600 rounded-lg text-white transition-all backdrop-blur-sm">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <div className="p-5">
                      <div className="flex items-center gap-3 mb-3">
                        <span style={{ background: `${currentTheme.primary}20`, color: currentTheme.primary }} className="px-3 py-1 rounded-full text-xs font-medium">
                          {recipe.category || '—'}
                        </span>
                        <span className="font-semibold" style={{ color: currentTheme.primary }}>
                          {formatPrice(recipe.price, currency)}
                        </span>
                      </div>

                      <h3 className="font-bold text-xl mb-3 line-clamp-2" style={{ color: currentTheme.textPrimary }}>
                        {recipe.name}
                      </h3>

                      <div className="flex items-center gap-4 text-sm mb-4" style={{ color: currentTheme.textSecondary }}>
                        <span className="flex items-center gap-1.5">
                          <Clock className="w-4 h-4" /> {recipe.prepTime + recipe.cookTime} min
                        </span>
                        <span>🍽️ {recipe.servings} {t.servings}</span>
                      </div>

                      <div className="flex flex-wrap gap-2">
                        {recipe.ingredients.slice(0, 3).map((ing, i) => (
                          <span key={i} className="text-xs px-3 py-1 rounded-full" style={{ backgroundColor: `${currentTheme.primary}15`, color: currentTheme.textSecondary }}>
                            {ing}
                          </span>
                        ))}
                        {recipe.ingredients.length > 3 && (
                          <span className="text-xs px-3 py-1 rounded-full" style={{ backgroundColor: `${currentTheme.primary}15`, color: currentTheme.textSecondary }}>
                            +{recipe.ingredients.length - 3}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Menu Page */}
        {activePage === 'menu' && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold" style={{ color: currentTheme.textPrimary }}>{t.weekMenu}</h2>
              <div className="flex items-center gap-3">
                <button onClick={() => setWeekOffset(w => w - 1)} style={secondaryBtnStyle} className="p-2 rounded-lg hover:scale-105 transition-all">
                  <ChevronUp className="w-5 h-5" />
                </button>
                <span className="text-sm font-medium" style={{ color: currentTheme.textSecondary }}>
                  {new Date(weekDates[0]).toLocaleDateString(language === 'sv' ? 'sv-SE' : 'en-US', { month: 'short', day: 'numeric' })}
                  {' - '}
                  {new Date(weekDatesFiltered[weekDatesFiltered.length - 1]).toLocaleDateString(language === 'sv' ? 'sv-SE' : 'en-US', { month: 'short', day: 'numeric' })}
                </span>
                <button onClick={() => setWeekOffset(w => w + 1)} style={secondaryBtnStyle} className="p-2 rounded-lg hover:scale-105 transition-all">
                  <ChevronDown className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {weekDays.map((day, idx) => {
                const date = weekDatesFiltered[idx];
                const dateKey = date.toISOString().split('T')[0];
                const dayRecipe = menuPlan[dateKey];

                return (
                  <div key={dateKey} style={cardStyle} className="rounded-2xl p-4 shadow-lg">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-bold text-lg" style={{ color: currentTheme.textPrimary }}>
                        {day}
                      </h3>
                      <span className="text-xs" style={{ color: currentTheme.textSecondary }}>
                        {date.toLocaleDateString(language === 'sv' ? 'sv-SE' : 'en-US', { month: 'short', day: 'numeric' })}
                      </span>
                    </div>

                    {dayRecipe ? (
                      <div className="space-y-3">
                        <div className="flex items-start gap-3">
                          {dayRecipe.image ? (
                            <img src={dayRecipe.image} alt="" className="w-16 h-16 rounded-lg object-cover" />
                          ) : (
                            <div className="w-16 h-16 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${currentTheme.primary}20` }}>
                              <UtensilsCrossed className="w-8 h-8" style={{ color: currentTheme.primary }} />
                            </div>
                          )}
                          <div className="flex-1">
                            <h4 className="font-semibold" style={{ color: currentTheme.textPrimary }}>{dayRecipe.name}</h4>
                            <p className="text-sm" style={{ color: currentTheme.textSecondary }}>{dayRecipe.category}</p>
                            <span className="text-sm font-medium" style={{ color: currentTheme.primary }}>
                              {formatPrice(dayRecipe.price, currency)}
                            </span>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <button onClick={() => setShowDayDetail(dateKey)} style={secondaryBtnStyle} className="px-3 py-1.5 rounded-lg text-xs hover:scale-105 transition-all">
                            {t.selectRecipe}
                          </button>
                          <button onClick={() => clearDayRecipe(dateKey)} className="px-3 py-1.5 rounded-lg text-xs bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-all">
                            {t.clearDay}
                          </button>
                        </div>
                      </div>
                    ) : (
                      <button
                        onClick={() => setShowDayDetail(dateKey)}
                        style={{ backgroundColor: `${currentTheme.primary}15`, borderColor: `${currentTheme.primary}40` }}
                        className="w-full py-6 rounded-xl text-center hover:scale-[1.02] transition-all border border-dashed"
                      >
                        <Plus className="w-8 h-8 mx-auto mb-2" style={{ color: currentTheme.primary }} />
                        <span style={{ color: currentTheme.textSecondary }}>{t.selectRecipe}</span>
                      </button>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Week total */}
            <div style={cardStyle} className="mt-6 rounded-2xl p-4 shadow-lg">
              <div className="flex items-center justify-between">
                <span className="font-medium" style={{ color: currentTheme.textPrimary }}>{t.totalCost}</span>
                <span className="text-2xl font-bold" style={{ color: currentTheme.primary }}>
                  {formatPrice(weekTotalCost, currency)}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Products Page */}
        {activePage === 'purchases' && (
          <div>
            <div className="flex justify-between items-center mb-6 flex-wrap gap-4">
              <h2 className="text-2xl font-bold" style={{ color: currentTheme.textPrimary }}>{t.products}</h2>
              <div className="flex gap-3 flex-wrap">
                <select
                  value={filterCategory}
                  onChange={e => setFilterCategory(e.target.value)}
                  style={inputStyle}
                  className="px-4 py-2 rounded-xl text-sm focus:outline-none"
                >
                  <option value="">All Categories</option>
                  {allCategories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
                <button onClick={openNewProduct} style={primaryBtnStyle} className="px-5 py-2.5 rounded-xl font-medium flex items-center gap-2 hover:scale-105 transition-all shadow-lg">
                  <Plus className="w-5 h-5" /> {t.addProduct}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {filteredProducts.map(product => (
                <div key={product.id} style={cardStyle} className="rounded-2xl p-4 shadow-lg">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-bold" style={{ color: currentTheme.textPrimary }}>{product.item}</h3>
                        <span style={{ background: `${currentTheme.primary}20`, color: currentTheme.primary }} className="px-2 py-0.5 rounded-full text-xs">
                          {product.category}
                        </span>
                      </div>
                      <div className="text-sm space-y-1" style={{ color: currentTheme.textSecondary }}>
                        <p>{t.artNr}: {product.artNr}</p>
                        <p>{t.unit}: {product.unit}</p>
                        {product.notes && <p className="italic">{product.notes}</p>}
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <span className="text-xl font-bold" style={{ color: currentTheme.primary }}>
                        {formatPrice(product.price, currency)}
                      </span>
                      <button
                        onClick={() => addToShoppingList(product)}
                        style={secondaryBtnStyle}
                        className="px-3 py-1.5 rounded-lg text-xs flex items-center gap-1 hover:scale-105 transition-all"
                      >
                        <Plus className="w-3 h-3" /> {t.addToShopping}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* CSV Actions */}
            <div className="mt-6 flex gap-3 flex-wrap">
              <button
                onClick={() => csvInputRef.current?.click()}
                style={secondaryBtnStyle}
                className="px-4 py-2 rounded-xl font-medium flex items-center gap-2 hover:scale-105 transition-all"
              >
                <Upload className="w-4 h-4" /> {t.importCSV}
              </button>
              <button
                onClick={downloadCSV}
                style={secondaryBtnStyle}
                className="px-4 py-2 rounded-xl font-medium flex items-center gap-2 hover:scale-105 transition-all"
              >
                <Download className="w-4 h-4" /> {t.exportCSV}
              </button>
            </div>
          </div>
        )}

        {/* Shopping List Page */}
        {activePage === 'shopping' && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold" style={{ color: currentTheme.textPrimary }}>{t.shoppingList}</h2>
              <button onClick={clearShoppingList} className="px-4 py-2 rounded-xl font-medium text-sm bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-all flex items-center gap-2">
                <Trash2 className="w-4 h-4" /> {t.clearList}
              </button>
            </div>

            {shoppingList.length === 0 ? (
              <div style={cardStyle} className="rounded-2xl p-12 text-center shadow-lg">
                <ShoppingCart className="w-16 h-16 mx-auto mb-4 opacity-70" style={{ color: currentTheme.primary }} />
                <p style={{ color: currentTheme.textSecondary }}>{t.emptyShopping}</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {shoppingList.map(item => (
                  <div key={item.product.id} style={cardStyle} className="rounded-2xl p-4 shadow-lg flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-2">
                        <button onClick={() => updateShoppingQuantity(item.product.id, -1)} className="p-1 rounded-lg hover:bg-black/10 transition-all" style={{ color: currentTheme.textPrimary }}>
                          <ChevronDown className="w-4 h-4" />
                        </button>
                        <span className="w-8 text-center font-bold" style={{ color: currentTheme.primary }}>{item.quantity}</span>
                        <button onClick={() => updateShoppingQuantity(item.product.id, 1)} className="p-1 rounded-lg hover:bg-black/10 transition-all" style={{ color: currentTheme.textPrimary }}>
                          <ChevronUp className="w-4 h-4" />
                        </button>
                      </div>
                      <div>
                        <h3 className="font-semibold" style={{ color: currentTheme.textPrimary }}>{item.product.item}</h3>
                        <p className="text-sm" style={{ color: currentTheme.textSecondary }}>{item.product.unit}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="font-bold" style={{ color: currentTheme.primary }}>
                        {formatPrice(item.product.price * item.quantity, currency)}
                      </span>
                      <button onClick={() => removeFromShoppingList(item.product.id)} className="p-2 bg-red-500/20 text-red-400 rounded-lg hover:bg-red-500/30 transition-all">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Total */}
            <div style={cardStyle} className="mt-6 rounded-2xl p-4 shadow-lg">
              <div className="flex items-center justify-between">
                <span className="text-xl font-medium" style={{ color: currentTheme.textPrimary }}>{t.total}</span>
                <span className="text-3xl font-bold" style={{ color: currentTheme.primary }}>
                  {formatPrice(shoppingTotal, currency)}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Settings Page */}
        {activePage === 'settings' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Theme Settings */}
            <div style={cardStyle} className="rounded-2xl p-6 shadow-lg">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold flex items-center gap-2" style={{ color: currentTheme.textPrimary }}>
                  <Palette className="w-5 h-5" /> {t.manageThemes}
                </h2>
                <button
                  onClick={() => setShowThemeModal(true)}
                  style={primaryBtnStyle}
                  className="px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1 hover:scale-105 transition-all"
                >
                  <Plus className="w-4 h-4" /> {t.createTheme}
                </button>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {[...THEMES, ...customThemes].map(theme => (
                  <div
                    key={theme.id}
                    onClick={() => setThemeId(theme.id)}
                    className={`p-3 rounded-xl cursor-pointer transition-all hover:scale-105 ${
                      themeId === theme.id ? 'ring-2 ring-offset-2' : ''
                    }`}
                    style={{
                      backgroundColor: theme.cardBg,
                      borderColor: theme.primary,
                      ...(themeId === theme.id ? { ringColor: theme.primary, boxShadow: `0 0 0 2px ${theme.cardBg}, 0 0 0 4px ${theme.primary}` } : {})
                    }}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-4 h-4 rounded-full" style={{ backgroundColor: theme.primary }} />
                      <span className="text-sm font-medium" style={{ color: theme.textPrimary }}>{theme.name}</span>
                    </div>
                    {customThemes.some(ct => ct.id === theme.id) && (
                      <button
                        onClick={(e) => { e.stopPropagation(); deleteCustomTheme(theme.id); }}
                        className="text-xs text-red-400 hover:text-red-500"
                      >
                        <Trash2 className="w-3 h-3 inline" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* User Settings */}
            <div style={cardStyle} className="rounded-2xl p-6 shadow-lg">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold flex items-center gap-2" style={{ color: currentTheme.textPrimary }}>
                  <Users className="w-5 h-5" /> {t.manageUsers}
                </h2>
                <button
                  onClick={openNewUser}
                  style={primaryBtnStyle}
                  className="px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-1 hover:scale-105 transition-all"
                >
                  <Plus className="w-4 h-4" /> {t.addUser}
                </button>
              </div>
              <div className="space-y-3">
                {users.map(user => (
                  <div key={user.id} className="flex items-center justify-between p-3 rounded-xl" style={{ backgroundColor: `${currentTheme.primary}10` }}>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full flex items-center justify-center font-bold" style={{ backgroundColor: currentTheme.primary, color: '#ffffff' }}>
                        {user.name[0]}
                      </div>
                      <div>
                        <p className="font-medium" style={{ color: currentTheme.textPrimary }}>{user.name}</p>
                        <p className="text-sm" style={{ color: currentTheme.textSecondary }}>{user.bio}</p>
                      </div>
                    </div>
                    {users.length > 1 && (
                      <button
                        onClick={() => deleteUser(user.id)}
                        className="p-2 text-red-400 hover:text-red-500 transition-all"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* General Settings */}
            <div style={cardStyle} className="rounded-2xl p-6 shadow-lg lg:col-span-2">
              <h2 className="text-xl font-bold mb-4 flex items-center gap-2" style={{ color: currentTheme.textPrimary }}>
                <Settings className="w-5 h-5" /> Inställningar
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>{t.language}</label>
                  <select
                    value={language}
                    onChange={e => setLanguage(e.target.value as any)}
                    style={inputStyle}
                    className="w-full px-4 py-2 rounded-xl focus:outline-none"
                  >
                    <option value="sv">Svenska</option>
                    <option value="en">English</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>{t.currency}</label>
                  <select
                    value={currency}
                    onChange={e => setCurrency(e.target.value as any)}
                    style={inputStyle}
                    className="w-full px-4 py-2 rounded-xl focus:outline-none"
                  >
                    <option value="SEK">SEK</option>
                    <option value="EUR">EUR</option>
                    <option value="USD">USD</option>
                    <option value="GBP">GBP</option>
                  </select>
                </div>
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    id="weekends"
                    checked={includeWeekends}
                    onChange={e => setIncludeWeekends(e.target.checked)}
                    className="w-5 h-5 rounded"
                    style={{ accentColor: currentTheme.primary }}
                  />
                  <label htmlFor="weekends" className="text-sm cursor-pointer" style={{ color: currentTheme.textPrimary }}>{t.weekends}</label>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Recipe Modal */}
      {showRecipeModal && editingRecipe && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div style={{ backgroundColor: currentTheme.cardBg, color: currentTheme.textPrimary }} className="rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold">{editingRecipe.id ? t.editRecipe : t.addRecipe}</h2>
                <button onClick={() => { setShowRecipeModal(false); setEditingRecipe(null); }} className="p-2 rounded-lg hover:bg-black/10 transition-all">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                {/* Image */}
                <div className="relative h-48 rounded-xl overflow-hidden bg-black/10">
                  {editingRecipe.image ? (
                    <>
                      <img
                        src={editingRecipe.image}
                        alt=""
                        className="w-full h-full object-cover"
                        style={{ filter: `brightness(${editingRecipe.imageBrightness}%) contrast(${editingRecipe.imageContrast}%)` }}
                      />
                      <button
                        onClick={() => setEditingRecipe(prev => prev ? { ...prev, image: '' } : null)}
                        className="absolute top-3 right-3 p-2 bg-red-500/80 text-white rounded-lg hover:bg-red-600 transition-all"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={() => recipeImageRef.current?.click()}
                      className="w-full h-full flex flex-col items-center justify-center gap-2 hover:scale-105 transition-all"
                    >
                      <ImageIcon className="w-12 h-12" style={{ color: currentTheme.primary }} />
                      <span style={{ color: currentTheme.textSecondary }}>{t.uploadImage}</span>
                    </button>
                  )}
                </div>

                {/* Image brightness/contrast */}
                {editingRecipe.image && (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm mb-1" style={{ color: currentTheme.textSecondary }}>Brightness</label>
                      <input
                        type="range"
                        min="50"
                        max="150"
                        value={editingRecipe.imageBrightness}
                        onChange={e => setEditingRecipe(prev => prev ? { ...prev, imageBrightness: parseInt(e.target.value) } : null)}
                        className="w-full"
                      />
                    </div>
                    <div>
                      <label className="block text-sm mb-1" style={{ color: currentTheme.textSecondary }}>Contrast</label>
                      <input
                        type="range"
                        min="50"
                        max="150"
                        value={editingRecipe.imageContrast}
                        onChange={e => setEditingRecipe(prev => prev ? { ...prev, imageContrast: parseInt(e.target.value) } : null)}
                        className="w-full"
                      />
                    </div>
                  </div>
                )}

                {/* Name */}
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>{t.item}</label>
                  <input
                    type="text"
                    value={editingRecipe.name}
                    onChange={e => setEditingRecipe(prev => prev ? { ...prev, name: e.target.value } : null)}
                    style={inputStyle}
                    className="w-full px-4 py-2 rounded-xl focus:outline-none"
                    placeholder="Recipe name"
                  />
                </div>

                {/* Category */}
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>{t.category}</label>
                  <input
                    type="text"
                    value={editingRecipe.category}
                    onChange={e => setEditingRecipe(prev => prev ? { ...prev, category: e.target.value } : null)}
                    style={inputStyle}
                    className="w-full px-4 py-2 rounded-xl focus:outline-none"
                    placeholder="Category"
                  />
                </div>

                {/* Ingredients */}
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>{t.ingredients}</label>
                  <div className="flex gap-2 mb-2">
                    <input
                      type="text"
                      value={newIngredient}
                      onChange={e => setNewIngredient(e.target.value)}
                      onKeyPress={e => e.key === 'Enter' && addIngredient()}
                      style={inputStyle}
                      className="flex-1 px-4 py-2 rounded-xl focus:outline-none"
                      placeholder="Add ingredient"
                    />
                    <button onClick={addIngredient} style={primaryBtnStyle} className="px-4 py-2 rounded-xl">
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="space-y-2">
                    {editingRecipe.ingredients.map((ing, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <input
                          type="text"
                          value={ing}
                          onChange={e => updateIngredient(i, e.target.value)}
                          style={inputStyle}
                          className="flex-1 px-3 py-1.5 rounded-lg text-sm focus:outline-none"
                        />
                        <button onClick={() => removeIngredient(i)} className="p-1.5 text-red-400 hover:text-red-500">
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Instructions */}
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>{t.instructions}</label>
                  <textarea
                    value={editingRecipe.instructions}
                    onChange={e => setEditingRecipe(prev => prev ? { ...prev, instructions: e.target.value } : null)}
                    style={inputStyle}
                    className="w-full px-4 py-2 rounded-xl focus:outline-none h-32 resize-none"
                    placeholder="Step by step instructions"
                  />
                </div>

                {/* Times */}
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>{t.prepTime} (min)</label>
                    <input
                      type="number"
                      value={editingRecipe.prepTime}
                      onChange={e => setEditingRecipe(prev => prev ? { ...prev, prepTime: parseInt(e.target.value) || 0 } : null)}
                      style={inputStyle}
                      className="w-full px-4 py-2 rounded-xl focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>{t.cookTime} (min)</label>
                    <input
                      type="number"
                      value={editingRecipe.cookTime}
                      onChange={e => setEditingRecipe(prev => prev ? { ...prev, cookTime: parseInt(e.target.value) || 0 } : null)}
                      style={inputStyle}
                      className="w-full px-4 py-2 rounded-xl focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>{t.servings}</label>
                    <input
                      type="number"
                      value={editingRecipe.servings}
                      onChange={e => setEditingRecipe(prev => prev ? { ...prev, servings: parseInt(e.target.value) || 1 } : null)}
                      style={inputStyle}
                      className="w-full px-4 py-2 rounded-xl focus:outline-none"
                    />
                  </div>
                </div>

                {/* Price */}
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>{t.price}</label>
                  <input
                    type="number"
                    step="0.01"
                    value={editingRecipe.price}
                    onChange={e => setEditingRecipe(prev => prev ? { ...prev, price: parseFloat(e.target.value) || 0 } : null)}
                    style={inputStyle}
                    className="w-full px-4 py-2 rounded-xl focus:outline-none"
                  />
                </div>

                {/* Notes */}
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>{t.notes}</label>
                  <textarea
                    value={editingRecipe.notes}
                    onChange={e => setEditingRecipe(prev => prev ? { ...prev, notes: e.target.value } : null)}
                    style={inputStyle}
                    className="w-full px-4 py-2 rounded-xl focus:outline-none h-20 resize-none"
                    placeholder="Additional notes"
                  />
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <button onClick={saveRecipe} style={primaryBtnStyle} className="flex-1 py-3 rounded-xl font-medium flex items-center justify-center gap-2 hover:scale-105 transition-all">
                  <Save className="w-4 h-4" /> {t.save}
                </button>
                <button onClick={() => { setShowRecipeModal(false); setEditingRecipe(null); }} style={secondaryBtnStyle} className="px-6 py-3 rounded-xl font-medium hover:scale-105 transition-all">
                  {t.cancel}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Product Modal */}
      {showProductModal && editingProduct && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div style={{ backgroundColor: currentTheme.cardBg, color: currentTheme.textPrimary }} className="rounded-2xl max-w-lg w-full shadow-2xl">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold">{editingProduct.id ? 'Redigera Produkt' : t.addProduct}</h2>
                <button onClick={() => { setShowProductModal(false); setEditingProduct(null); }} className="p-2 rounded-lg hover:bg-black/10 transition-all">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>{t.item}</label>
                  <input
                    type="text"
                    value={editingProduct.item}
                    onChange={e => setEditingProduct(prev => prev ? { ...prev, item: e.target.value } : null)}
                    style={inputStyle}
                    className="w-full px-4 py-2 rounded-xl focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>{t.artNr}</label>
                  <input
                    type="text"
                    value={editingProduct.artNr}
                    onChange={e => setEditingProduct(prev => prev ? { ...prev, artNr: e.target.value } : null)}
                    style={inputStyle}
                    className="w-full px-4 py-2 rounded-xl focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>{t.category}</label>
                  <input
                    type="text"
                    value={editingProduct.category}
                    onChange={e => setEditingProduct(prev => prev ? { ...prev, category: e.target.value } : null)}
                    style={inputStyle}
                    className="w-full px-4 py-2 rounded-xl focus:outline-none"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>{t.price}</label>
                    <input
                      type="number"
                      step="0.01"
                      value={editingProduct.price}
                      onChange={e => setEditingProduct(prev => prev ? { ...prev, price: parseFloat(e.target.value) || 0 } : null)}
                      style={inputStyle}
                      className="w-full px-4 py-2 rounded-xl focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>{t.unit}</label>
                    <input
                      type="text"
                      value={editingProduct.unit}
                      onChange={e => setEditingProduct(prev => prev ? { ...prev, unit: e.target.value } : null)}
                      style={inputStyle}
                      className="w-full px-4 py-2 rounded-xl focus:outline-none"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>{t.notes}</label>
                  <textarea
                    value={editingProduct.notes}
                    onChange={e => setEditingProduct(prev => prev ? { ...prev, notes: e.target.value } : null)}
                    style={inputStyle}
                    className="w-full px-4 py-2 rounded-xl focus:outline-none h-20 resize-none"
                  />
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <button onClick={saveProduct} style={primaryBtnStyle} className="flex-1 py-3 rounded-xl font-medium flex items-center justify-center gap-2 hover:scale-105 transition-all">
                  <Save className="w-4 h-4" /> {t.save}
                </button>
                <button onClick={() => { setShowProductModal(false); setEditingProduct(null); }} style={secondaryBtnStyle} className="px-6 py-3 rounded-xl font-medium hover:scale-105 transition-all">
                  {t.cancel}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Day Detail Modal */}
      {showDayDetail && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div style={{ backgroundColor: currentTheme.cardBg, color: currentTheme.textPrimary }} className="rounded-2xl max-w-2xl w-full max-h-[80vh] overflow-y-auto shadow-2xl">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold">{t.selectRecipe}</h2>
                <button onClick={() => setShowDayDetail(null)} className="p-2 rounded-lg hover:bg-black/10 transition-all">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {recipes.map(recipe => (
                  <button
                    key={recipe.id}
                    onClick={() => setDayRecipe(showDayDetail, recipe)}
                    className="p-3 rounded-xl text-left hover:scale-[1.02] transition-all border"
                    style={{ borderColor: `${currentTheme.primary}33`, backgroundColor: `${currentTheme.primary}10` }}
                  >
                    <div className="flex items-center gap-3">
                      {recipe.image ? (
                        <img src={recipe.image} alt="" className="w-12 h-12 rounded-lg object-cover" />
                      ) : (
                        <div className="w-12 h-12 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${currentTheme.primary}30` }}>
                          <UtensilsCrossed className="w-6 h-6" style={{ color: currentTheme.primary }} />
                        </div>
                      )}
                      <div className="flex-1">
                        <h3 className="font-semibold" style={{ color: currentTheme.textPrimary }}>{recipe.name}</h3>
                        <p className="text-sm" style={{ color: currentTheme.textSecondary }}>{recipe.category}</p>
                        <span className="text-sm font-medium" style={{ color: currentTheme.primary }}>
                          {formatPrice(recipe.price, currency)}
                        </span>
                      </div>
                    </div>
                  </button>
                ))}
                <button
                  onClick={() => setDayRecipe(showDayDetail, null)}
                  className="p-3 rounded-xl text-left hover:scale-[1.02] transition-all border border-dashed"
                  style={{ borderColor: `${currentTheme.primary}40` }}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${currentTheme.primary}20` }}>
                      <X className="w-6 h-6" style={{ color: currentTheme.primary }} />
                    </div>
                    <div>
                      <h3 className="font-semibold" style={{ color: currentTheme.textPrimary }}>{t.clearDay}</h3>
                      <p className="text-sm" style={{ color: currentTheme.textSecondary }}>Remove recipe from this day</p>
                    </div>
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* User Modal */}
      {showUserModal && editingUser && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div style={{ backgroundColor: currentTheme.cardBg, color: currentTheme.textPrimary }} className="rounded-2xl max-w-md w-full shadow-2xl">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold">{editingUser.id ? 'Redigera Användare' : t.addUser}</h2>
                <button onClick={() => { setShowUserModal(false); setEditingUser(null); }} className="p-2 rounded-lg hover:bg-black/10 transition-all">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>{t.userName}</label>
                  <input
                    type="text"
                    value={editingUser.name}
                    onChange={e => setEditingUser(prev => prev ? { ...prev, name: e.target.value } : null)}
                    style={inputStyle}
                    className="w-full px-4 py-2 rounded-xl focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>{t.bio}</label>
                  <textarea
                    value={editingUser.bio}
                    onChange={e => setEditingUser(prev => prev ? { ...prev, bio: e.target.value } : null)}
                    style={inputStyle}
                    className="w-full px-4 py-2 rounded-xl focus:outline-none h-24 resize-none"
                  />
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <button onClick={saveUser} style={primaryBtnStyle} className="flex-1 py-3 rounded-xl font-medium flex items-center justify-center gap-2 hover:scale-105 transition-all">
                  <Save className="w-4 h-4" /> {t.save}
                </button>
                <button onClick={() => { setShowUserModal(false); setEditingUser(null); }} style={secondaryBtnStyle} className="px-6 py-3 rounded-xl font-medium hover:scale-105 transition-all">
                  {t.cancel}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Theme Modal */}
      {showThemeModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div style={{ backgroundColor: currentTheme.cardBg, color: currentTheme.textPrimary }} className="rounded-2xl max-w-md w-full shadow-2xl">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold">{t.createTheme}</h2>
                <button onClick={() => setShowThemeModal(false)} className="p-2 rounded-lg hover:bg-black/10 transition-all">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>{t.themeName}</label>
                  <input
                    type="text"
                    value={newThemeName}
                    onChange={e => setNewThemeName(e.target.value)}
                    style={inputStyle}
                    className="w-full px-4 py-2 rounded-xl focus:outline-none"
                    placeholder="My Theme"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>{t.primaryColor}</label>
                  <div className="flex gap-2">
                    <input
                      type="color"
                      value={newThemePrimary}
                      onChange={e => setNewThemePrimary(e.target.value)}
                      className="w-16 h-10 rounded-lg cursor-pointer"
                    />
                    <input
                      type="text"
                      value={newThemePrimary}
                      onChange={e => setNewThemePrimary(e.target.value)}
                      style={inputStyle}
                      className="flex-1 px-4 py-2 rounded-xl focus:outline-none monospace"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>{t.bgColor}</label>
                  <div className="flex gap-2">
                    <input
                      type="color"
                      value={newThemeBg}
                      onChange={e => setNewThemeBg(e.target.value)}
                      className="w-16 h-10 rounded-lg cursor-pointer"
                    />
                    <input
                      type="text"
                      value={newThemeBg}
                      onChange={e => setNewThemeBg(e.target.value)}
                      style={inputStyle}
                      className="flex-1 px-4 py-2 rounded-xl focus:outline-none monospace"
                    />
                  </div>
                </div>
                {/* Preview */}
                <div className="p-4 rounded-xl" style={{ backgroundColor: newThemeBg, color: newThemeBg + 'cc' === '#ffffffcc' ? '#000' : '#fff' }}>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-10 h-10 rounded-full" style={{ backgroundColor: newThemePrimary }} />
                    <span className="font-bold">Preview</span>
                  </div>
                  <button style={{ background: `linear-gradient(135deg, ${newThemePrimary}, ${newThemePrimary}dd)` }} className="px-4 py-2 rounded-lg text-white text-sm">
                    Sample Button
                  </button>
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <button onClick={addCustomTheme} style={primaryBtnStyle} className="flex-1 py-3 rounded-xl font-medium flex items-center justify-center gap-2 hover:scale-105 transition-all">
                  <Check className="w-4 h-4" /> Create
                </button>
                <button onClick={() => setShowThemeModal(false)} style={secondaryBtnStyle} className="px-6 py-3 rounded-xl font-medium hover:scale-105 transition-all">
                  {t.cancel}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}